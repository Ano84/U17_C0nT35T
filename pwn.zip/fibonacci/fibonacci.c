// gcc -O2 -fno-stack-protector -o fibonacci fibonacci.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void init() {
	setbuf(stdin, NULL);
	setbuf(stdout, NULL);
	alarm(30);
}

void win() {
	char flag[256];
	FILE* f;
	memset(flag, 0, 256);
	f = fopen("/home/fibonacci_user/flag", "r");
	fread(flag, 256, 1, f);
	printf("%s\n", flag);	
	exit(0);
}

void fibonacci() {
	double A[16];
	int n, i;

	printf("n = "); scanf("%d", &n);
	fflush(stdin);
	printf("x1 = "); scanf("%lf", &A[0]);
	fflush(stdin);
	printf("x2 = "); scanf("%lf", &A[1]);
	fflush(stdin);

	for (i=2; i<n-1; i++) {
		A[i] = A[i-1] + A[i-2];
	}
	*((unsigned long long *)A + i)= (unsigned long long)(A[i-1] + A[i-2]);

	for (i=0; i<n-1; i++) {
		printf("%ld ", (unsigned long long)A[i]);
	}
	printf("%ld\n", *((unsigned long long *)A + i));
}

void main() {
	init();
	fibonacci();
}