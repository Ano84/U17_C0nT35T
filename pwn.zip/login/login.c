// gcc -m32 -o login login.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void init() {
	setbuf(stdin, NULL);
	setbuf(stdout, NULL);
	setbuf(stderr, NULL);
	alarm(60);
}

void readn(char* buf, unsigned int n) {
	char c;
	unsigned int i;
	for (i=0; i<n-1; i++) {
		read(0, &c, 1);
		if (c == '\n')
			break;
		buf[i] = c;
	}
	buf[i] = 0;
}

void main() {

	FILE* f;
	char tmp1[256];
	char tmp2[256];
	char password[256];

	init();
	memset(tmp1, 0, 256);
	memset(tmp2, 0, 256);
	memset(password, 0, 256);

	f = fopen("/home/login_user/flag", "r");
	fread(password, 256, 1, f);

	char tired[4];
	while (1) {
		printf("Username: ");
		readn(tmp1, 256);

		printf("Password: ");
		readn(tmp2, 256);
		if (!strncmp(tmp1, "root", 4) && !strncmp(tmp2, password, strlen(tmp2)))
			printf("Welcome, pwner!\n");
		else
			printf("Login fail.\n");
		printf("Tired? (y/n) ");
		readn(tired, 4);
		if (tired[0] == 'y' || tired[0] == 'Y')
			break;
	}
}